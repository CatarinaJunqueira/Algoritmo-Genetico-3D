% Nome: Regra de Descarregamento 2 - Rd2 

%---------------------------------------------------------------------%
%              Regra de Descarregamento do Navio (Rd2)                %
%---------------------------------------------------------------------%
% Retira todos os cont�ineres do Navio para carreg�-los posteriormente
% usando alguma regra de carregamento.

function [MovGeral, Navio,lista_descarregamento] = Rd2(Navio, NPorto, porto, navio, RegraRetirada,RegraCarregamento,lista_descarregamento)

qntd=length(find(Navio~=0));
%lista_desc=zeros(size(lista_descarregamento,1),size(lista_descarregamento,2));
k=length(find(lista_descarregamento(:,2)==NPorto));
patio_imp=zeros(ceil(sqrt(k)),ceil(sqrt(k))); % �rea reservada para os cont�ineres de importa��o
patio_transb=zeros(ceil(sqrt(length(porto)-k)),ceil(sqrt(length(porto)-k))); % �rea reservada para os cont�ineres de transbordo
[linha,coluna]=size(Navio);

     for i=1:linha
        for j=1:coluna
            if Navio(i,j)~=0 % se a posi��o � diferente de zero
               [row]=find(lista_descarregamento(:,1)==Navio(i,j));
                if lista_descarregamento(row,2)== NPorto
                   [patio_imp] = Rc_Imp(patio_imp,Navio(i,j));% se o destino deste cont � este porto, retira e coloca na �rea reservada
                   Navio(i,j)=0; 
                   lista_descarregamento(row,:)=[];
                else % se o cont�iner n�o vai ficar no porto em que o navio est�
                     % retira e coloca na �rea de transbordo para depois colocar
                     % de volta no navio
                   [patio_transb] = Rc_Imp(patio_transb,Navio(i,j)); 
                   Navio(i,j)=0;
                end
            end
        end   
    end
    
% Terminado o descarregamento
%----------------------------------------------------------------------------------------------------------------------%
% Agora � necess�rio carregar os cont�ineres que foram descarregados, mas que n�o tinham como destino final este porto  
   
    if sum(sum(patio_transb)) ~= 0        
        [movgeral,~,Navio] = Rt_descarregamento(patio_transb,navio,RegraRetirada,Navio,RegraCarregamento);
        MovGeral = qntd + movgeral; % contando o n�mero de movimentos
    else
        MovGeral = qntd;        
    end  
    
%     for b=1:length(find(lista_descarregamento(:,1)~=0))
%     [r,c]=find(Navio==lista_descarregamento(b,1))
%     lista_descarregamento(b,3)=r
%     lista_descarregamento(b,4)=c        
%     end

end