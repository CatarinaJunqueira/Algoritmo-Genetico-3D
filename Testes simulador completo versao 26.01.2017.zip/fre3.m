%----------------------------------------------------%
%----------------------------------------------------%
% Elabora��o da Regra R1 de Entrada.                 %
%----------------------------------------------------%
%----------------------------------------------------%
% Procedimento de preenchimento:                     %
%----------------------------------------------------%
%  (1) Considera-se que a ordem de preenchimento
%      das cargas no navios ->, ou seja, da 
%      direita para a esquerda de baixo para cima.  
%      m ^
%        |
%        |
%      1 -----> 
%        1    n
%
%  (2) Recebe uma matriz M vazia ou parcialmente 
%      preenchida, bem como um vetor D com cargas
%      do i-esimo porto.
%
%  (3) Retorna a matriz M com as cargas contidas no
%      vetor D preenchidas de acordo com a regra RE1.
%
%  (4) M deve ser de baixo para cima
%
%----------------------------------------------------%
function [M,MovGeral] = fre3(M,D) 

MovGeral = sum(D);
% display(MovGeral);

  % Ordenando os elementos de D em ordem decrescente 
  % de porto.
  %[qq, ind] = sort(D,'descend');
  
  % Laco para preencher a matriz usando ->.  
  [m,n]=size(M);
  tam = sum(D);
  k=1;
    
  i=1; %come�a do tamanho de linhas (linha final)
  while ((i <= m)&&(k <= tam)) 
    j=n;  %come�a do tamnho de colunas (coluna final)
    while ((j >=1)&&(k <= tam))
      % Se houver um espa�o vazio, ent�o, ponha um container
      % que esta em v.
      if (M(i,j) == 0) 
          
           [D, ind] = indice(D);
        
        if (ind == 0)
            break;
        end
        
        M(i,j) = ind;   
        k = k + 1;            
      end    
      j = j - 1;
    end    
    i = i + 1;
  end 
  
  % Mensagem de aviso de infactibilidade do problema !!
  if (k < tam) 
    fprintf(1,'Problema na fun��o fre1 !! \n');
    fprintf(1,'N�o foi poss�vel carregar todos os containeres!! \n');
    fprintf(1,'Espaco insufiente !! \n');
  end   
end


function [D, ind] = indice(D)

  ind = 0;

  for x = (-size(D,2):-1)*-1
     
      if (D(x) ~= 0)
          
          ind = x;
          D(x) = D(x) -1;
          break;
          
      end
      
      
  end
        
end
  

%----------------------------------------------------%