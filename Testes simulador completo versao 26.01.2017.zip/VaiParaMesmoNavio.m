
function [pool] = VaiParaMesmoNavio(patio,navio,posicao_navio,posicao_acima)
d=patio(posicao_navio(1,1),posicao_navio(1,2));
N1=navio(d);  %identificando para qual navio vai o conteiner que vai ser retirado
e=patio( posicao_acima(1,1),posicao_acima(1,2));
N2=navio(e);

    if ((N1 == N2)) %Verifica se � os navios de destino s�o iguais.
        pool = 1;  %Se vai para o mesmo navio, pool =1 
    else
        pool = 0; %Se nao vai para o mesmo navio, pool =0 
    end
end