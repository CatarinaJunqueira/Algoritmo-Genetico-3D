% Fun��o que realiza a simula��o das regras de uma 
% entrada e saida fornecida por uma dada solucao.

%[M,value] = simulaRegras(navio{k,1:1},patio{k,1:1},porto{k,1:1},Rt,Rc,Rd,M,k,length(v));
    
function [Navio,value,lista_descarregamento] = simulaRegras(navio,patio,porto,RegraRetirada,RegraCarregamento,RegraDescarregamento,Navio,k,max,lista_descarregamento)

  % Numero de movimentos realizados para carregar 
  % e descarregar containeres de 1 navio para 1
  % porto e um conjunto de regras dado por fre 
  % (regra de entrada) e frs (regra de saida).
  value = 0;
  
  % Vetor de conteineres resultante dos descarregamentos 
  % efetuados em um dado porto. Estes conteineres serao
  % somados aos que serao embarcados no porto atual com
  % destino aos portos mais a frente.
  % vC = [];

  % Verificando se nao estamos no primeiro porto onde
  % os conteineres sao apenas carregados !!
  
    if k==1
      [MovGeral,Navio,lista_descarregamento] = Rt(patio,navio,RegraRetirada,Navio,RegraCarregamento,porto,lista_descarregamento);
      value=value+MovGeral;      
    end    
  
    if k~=1
        y=unique(lista_descarregamento(:,2));
        yy=ismember(k,y);
        if yy==1
       [MovGeral,Navio,lista_descarregamento] = Rd(Navio, k, porto, navio, RegraRetirada,RegraCarregamento,RegraDescarregamento,lista_descarregamento);
       value=value+MovGeral;
        end
       
       [MovGeral,Navio,lista_descarregamento] = Rt(patio,navio,RegraRetirada,Navio,RegraCarregamento,porto,lista_descarregamento);
       value=value+MovGeral;
    end

%   if (descarregamento(k)== 1)
%     % Descarregar containeres contidos na matriz M 
%     % e que pertencem ao porto k de acordo com a 
%     % regra de saida dada no arquivo cujo nome 
%     % esta contido na string frs.
%     [nmov,M,aCarregar] = feval(frs,M,k);
%     
%     if (sum(aCarregar) > 0)
%         [M] = feval(fre,M,aCarregar);
%         value = value + sum(aCarregar);
%     end
%     
%     value = value + nmov;
%   end   
%   
%   if (k ~= max)
%   
%   [nmov] = feval(Rt,patio);
%   
%   value = value + nmov;
%   
%   % Carregar matriz M com containeres contidos 
%   % em D segundo a regra dado na string fre.
%   [M] = feval(fre,M,D);
%   
%   
%   % Contabilizando o numero de containeres carregados.
%   % (Nao eh necessaria nenhuma movimentacao dos demais
%   %  containeres para colocar outros. Isto so pode ser 
%   %  realizado no momento de descarga).
%   value = value + sum(D);
%   
%   end
%   
     
  
end
  
 
  
%   % Carregar matriz M com containeres contidos 
%   % em D segundo a regra dado na string fre.
%   [M] = feval(fre,M,D);
%   
%   % Contabilizando o numero de containeres carregados.
%   % (Nao eh necessaria nenhuma movimentacao dos demais
%   %  containeres para colocar outros. Isto so pode ser 
%   %  realizado no momento de descarga).
%   value = value + sum(D);
%   
%   % Verificando se nao estamos no primeiro porto onde
%   % apenas os containeres sao carregados !!
%   if (k > 1)
%     % Descarregar containeres contidos na matriz M 
%     % e que pertencem ao porto k de acordo com a 
%     % regra de saida dada no arquivo cujo nome 
%     % esta contido na string frs.
%     [M,nmov] = feval(frs,M,k);
%     value = value + nmov;
%   end    