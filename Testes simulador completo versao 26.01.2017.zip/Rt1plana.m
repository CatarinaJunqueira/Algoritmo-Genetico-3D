

function [mov_total1] = Rt1(patio)


caso  = 1;
mov_total1 = 0;

  for x = (1:length(patio))
    if patio{x}(caso) == 1
       mov_total1 = mov_total1 + 1;
       %patio{x} = 0; %adicionar 'patio' do lado do mov_total1%
    end
  end
  
end

