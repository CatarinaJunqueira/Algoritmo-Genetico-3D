% Nome: Regra de Descarregamento - Rd 

%---------------------------------------------------------------------%
%               Regra de Descarregamento do Navio (Rd)                %
%---------------------------------------------------------------------%


function [MovGeral,Navio,lista_descarregamento] = Rd(Navio, NPorto, porto, navio, RegraRetirada,RegraCarregamento,RegraDescarregamento,lista_descarregamento)

%--------------------------------------------------------------------------%
% identificando a regra que vai ser utilizada  
Rd = strcat('Rd',int2str(RegraDescarregamento));
%--------------------------------------------------------------------------%

[MovGeral, Navio,lista_descarregamento] = feval(Rd,Navio, NPorto, porto, navio, RegraRetirada,RegraCarregamento,lista_descarregamento);
   

end