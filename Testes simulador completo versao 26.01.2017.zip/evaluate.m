% Funcao responsavel por realizar a avaliacao das solucoes 
% propostas pelo algoritmo genetico.
function [population] = evaluate(POPSIZE,population,Navio,navio,porto,patio,MAXGENS,generation,lista_descarregamento)
         
   %--------------------------------------------//   
   % Calculation of costs by the rules for      //
   % each member in the population !!!          // 
   %--------------------------------------------//
   for mem=1:POPSIZE    
       
        if (mem == POPSIZE && generation == MAXGENS)
        ultima_geracao = 1;
        else
        ultima_geracao = 0;
        end
           
     [fitness] = sol2fo(population(mem).gene,patio,Navio,navio,porto,ultima_geracao,lista_descarregamento); 
     % Considerando a medida de infactibilidade no fitness, pois 
     % como o problema � de minimiza��o quanto maior o fitness
     % e a infactibilidade, pior � a solu��o.
     population(mem).fitness = 1/(1 + fitness);
   end 
end
      
       