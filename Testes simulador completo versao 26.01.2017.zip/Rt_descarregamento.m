
% Nome: Regra de Retirada - Rt ----> uso essa regra porque aqui eu tenho
% que rodar para todos os navios, diferentemente da regra Rt que roda s�
% para o navio 1.

%---------------------------------------------------------------------%
%                  Regra de Retirada do P�tio (Rt)                    %
%---------------------------------------------------------------------%

% Par�metros de entrada: P�tio, Navio e M�trica (n�mero da regra a ser utilizada)
% patio=[0,0,0,0,0;0,0,15,16,0;11,12,13,14,0;6,7,8,9,10;1,2,3,4,5];
% navio=[3,1,5,1,1,1,4,4,1,5,1,5,5,3,3,4];
% porto=[5,2,5,2,2,2,3,4,2,5,4,5,4,3,3,4];
% RegraRetirada=1; % n�mero da regra de retirada do p�tio
% Navio=zeros(5,5);
% RegraCarregamento=1; % n�mero da regra de carregamento no navio
% [MovGeral,tempo,DistanciaTotal,Navio] = Rt(patio,navio,RegraRetirada,Navio,RegraCarregamento)
%[MovGeral,Navio,lista_descarregamento] = Rt(patio,navio,RegraRetirada,Navio,RegraCarregamento,porto,lista_descarregamento)

function [MovGeral,tempo,Navio] = Rt_descarregamento(patio,~,RegraRetirada,Navio,RegraCarregamento)
tic;
MovGeral=0;
%id_navio = unique(navio); % identifica quais s�o os navios de destino e os coloca em ordem crescente
%k=length(id_navio); %vou rodar a regra para a quantidade de navios existentes
%DistanciaTotal=0;
   % for i=1:k

    %--------------------------------------------------------------------------%
    % identificando a regra que vai ser utilizada (qual localiza e qual vazio) % 
  %  localiza = strcat('encontra',int2str(RegraRetirada));
    vzio = strcat('desguarnecido',int2str(RegraRetirada));
    %--------------------------------------------------------------------------%
     
    [l_navio] = enc_ALL(patio); % Chamando o localiza, traz uma lista das posi��es dos cont�ineres que v�o ser retirados.
    
    [mov_total,~,Navio] = Mover_Desc(patio,l_navio,vzio,Navio,RegraCarregamento);
    %[mov_total,patio,Navio] = mover1(patio,l_navio,vzio,Navio,RegraCarregamento);
    MovGeral=MovGeral+mov_total;
    %DistanciaTotal=DistanciaTotal+Distancia;

   % end
tempo=toc;
end  