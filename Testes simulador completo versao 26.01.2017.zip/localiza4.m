%indices=[0,0,0,0,0;0,0,15,16,0;11,12,13,14,0;6,7,8,9,10;1,2,3,4,5];
%navio=[3,1,5,1,1,1,4,4,1,5,1,5,5,5,3,3];
%id_navio=1;

%posicoes=[5,3;5,2;3,1];

%posicoes=[5,2;5,4;5,5;4,1;4,4;3,1];
%----------------------------------------%
% localiza para a regra Rt4:    9 6 3
%                               8 5 2
%                               7 4 1
%----------------------------------------%

function [posicoes] = localiza4(indices,navio,id_navio) % localiza posi��o e n�o conte�do.

[coluna]=find(navio==id_navio);
 b=numel(coluna); %n�mero de elementos que v�o para o navio i
 row=zeros(1,b);
 col=zeros(1,b);
  
 for i=1:b
 [row(i),col(i)]=find(indices==coluna(i));
 end

 u=unique(col);
 u=sort(u,'descend');
 Row1{1,length(u)}=[];
 
 for j=1:length(u)
     [coluna_col]=find(col==u(j)); %Encontra a posi��o dos valores de u.
     a=length(coluna_col);  
     Row=zeros(1,a);
     for k=1:a
         Row(k)=row(coluna_col(k)); %Encontra o valor que est� na posi��o salva em "coluna_row"
     end
     Row1{j}=Row;
     Row1{j}=sort(Row1{j},'descend');
 end
  Row1=cell2mat(Row1); % transforma a c�lula em vetor
  Col=sort(col,'descend');
  posicoes=[Row1;Col]';

end