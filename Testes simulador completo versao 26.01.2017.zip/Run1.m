 

load cenario1

[MovGeral,tempo,DistanciaTotal] = Rt(patio,navio,1,porto);