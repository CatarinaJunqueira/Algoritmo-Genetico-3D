% Nome: Gera Cen�rio

%-------------------------------------------------------------------------%
% Gera cen�rios de teste para serem utilizados pelo programa de simula��o %
%-------------------------------------------------------------------------%
% m = input('N�mero de linhas do p�tio = ');
% n = input('N�mero de colunas do p�tio = ');
% q = input('Quantidade de cont�ineres = '); 
% X = input('N�mero de navios = ');
% NP = input('N�mero de portos percorridos = ');
% [patio,navio,porto,Navio,np,lista_descarregamento,MC] = gera_cenario(7,10,6,4)
function[patio,navio,porto,Navio,np,lista_descarregamento,MC] = gera_cenario(m,n,X,NP)
y=1;
patio=cell(NP-1,1);
navio=cell(NP-1,1);
porto=cell(NP-1,1);
MC=zeros(NP-1,1);
np=NP;
XX=2;
    while y<=NP-1
     q=randi([ceil(m*n*0.50),ceil(m*n*0.90)],1); %Quantidade de cont�ineres ocupam de 0.49 a 0.89 de cada patio
     MC(y)=q;
     if y==1
         A=1;
         B=q;
         [ppatio,nnavio,pporto] = gera_patio(m,n,q,XX,X,np,A,B);
     end
     
     if y>1
         A=B+1;
         B=B+q;
         XX=XX+1;
         [ppatio,nnavio,pporto] = gera_patio(m,n,q,XX,X,np,A,B);         
     end
        patio{y,1}=ppatio;
        navio{y,1}=nnavio;
        porto{y,1}=pporto;
        y=y+1;
    end 
    
    tam=0;
    for i= 1:NP-1 % contando a qntd de cont que serao embarcados no navio ao longo da viagem toda 
    u=length(find(navio{i,1}==1)); % � =1 porque eu rodo a simulacao tirando do patio
                                   % os conteineres que tem destino o navio
                                   % 1
    tam=tam+u; % 'tam' me da a qntd de cont que serao embarcados no navio ao longo da viagem por todos os portos 
    end
    lista_descarregamento=zeros(tam*np,2);
    %Sabendo quantos conteineres serao embarcados, crio um Navio (matriz de
    %ocupacao que tenha capacidade para embarcar todos os conteineres.
    Navio=zeros((ceil((sqrt(tam)/2)*1.1)),ceil(tam*1.1/(ceil(sqrt(tam)/2))));
    MC=sum(MC);
    save('cenarioTESTE_II.mat','patio','navio','porto','Navio','np','lista_descarregamento','MC');
    
end