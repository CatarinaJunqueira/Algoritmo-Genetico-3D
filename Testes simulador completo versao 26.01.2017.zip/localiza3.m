%indices=[0,0,0,0,0;0,0,15,16,0;11,12,13,14,0;6,7,8,9,10;1,2,3,4,5];
%navio=[3,1,5,1,1,1,4,4,1,5,1,5,5,5,3,3];
%id_navio=1;

%posicoes=[5,3;5,2;3,1];

%posicoes=[5,2;5,4;5,5;4,1;4,4;3,1];
%----------------------------------------%
% localiza para a regra Rt3:    9 8 7
%                               6 5 4
%                               3 2 1
%----------------------------------------%

function [posicoes] = localiza3(indices,navio,id_navio) % localiza posi��o e n�o conte�do.

[coluna]=find(navio==id_navio);
 b=numel(coluna); %n�mero de elementos que v�o para o navio i
 row=zeros(1,b);
 col=zeros(1,b);
  
 for i=1:b
 [row(i),col(i)]=find(indices==coluna(i));
 end

 u=unique(row);
 u=sort(u,'descend');
 Col1{1,length(u)}=[];
 
 for j=1:length(u)
     [coluna_row]=find(row==u(j)); %Encontra a posi��o dos valores de u.
     a=length(coluna_row);  
     Col=zeros(1,a);
     for k=1:a
         Col(k)=col(coluna_row(k)); %Encontra o valor que est� na posi��o salva em "coluna_row"
     end
     Col1{j}=Col;
     Col1{j}=sort(Col1{j},'descend');
 end
  Col1=cell2mat(Col1); % transforma a c�lula em vetor
  Row=sort(row,'descend');
  posicoes=[Row;Col1]';
% posicoes=sortrows(posicoes,-1); % corrigindo a ordem
  display(posicoes);
 
end