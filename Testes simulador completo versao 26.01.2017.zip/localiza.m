
function posicoes = localiza2(indices,navio,id_conteiner) % localiza posi��o e n�o conte�do.

 [coluna]=find(navio==id_conteiner);
 b=numel(coluna); %n�mero de elementos que v�o para o navio i
 
 for i=1:b
 [row(i),col(i)]=find(indices==coluna(i));
 end
posicoes=[row;col]';

end

