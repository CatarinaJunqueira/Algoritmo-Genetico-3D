% Nome: Regra de Descarregamento 1 - Rd1 

%---------------------------------------------------------------------%
%              Regra de Descarregamento do Navio (Rd1)                %
%---------------------------------------------------------------------%
%Nesta regra, quando o navio chega a um porto p, s�o removidos todos os
%cont�ineres cujo destino � p e todos os cont�ineres que est�o acima dos
%cont�ineres do porto p e cujos destinos s�o os portos p+j


function [MovGeral, Navio,lista_descarregamento] = Rd1(Navio, NPorto, porto, navio, RegraRetirada,RegraCarregamento,lista_descarregamento)

MovGeral=0;
k=length(find(lista_descarregamento(:,2)==NPorto));
patio_imp=zeros(ceil(sqrt(k)),ceil(sqrt(k))); % �rea reservada para os cont�ineres de importa��o
patio_transb=zeros(ceil(sqrt(length(porto)-k)),ceil(sqrt(length(porto)-k))); % �rea reservada para os cont�ineres de transbordo
[linha,coluna]=size(Navio);
%length(find(lista_descarregamento(:,1)~=0))
    for i=1:linha
        for j=1:coluna
            if Navio(i,j)~=0 % se a posi��o � diferente de zero
                [row]=find(lista_descarregamento(:,1)==Navio(i,j));   
                if lista_descarregamento(row,2)== NPorto % se o cont�iner vai para o porto em que o navio est�
                    if ((i-1 == 0) || (Navio(i-1,j) == 0)) %Verifica se � topo ou se a posi��o acima � vazia.
                         [patio_imp] = Rc_Imp(patio_imp,Navio(i,j)); % se for topo retira e coloca no lugar reservado do p�tio
                         Navio(i,j)=0;
                         MovGeral=MovGeral+1;
                         lista_descarregamento(row,:)=[];                         
                    else % se n�o � topo, remove o cont objetivo e os que est�o em cima
                         acima = quem_acima(Navio,[i,j]); %vejo quem est� acima dessa posi��o
                         qtde_troca = 1;
                         trocas =0;

                        while(qtde_troca > 0)
                             qtde_troca = 0; %Condicao de parada
                             max_acima = size(acima,1);

                                if (trocas == max_acima) 
                                    break
                                else
                                    trocas = trocas +1;
                                end

                                   t = size(acima,1); %quantidade de cont�ineres acima
                                   contador=1;

                                    for k = (1:t) % de 1 at� quantidade de cont�ineres acima
                                        if (acima(contador)~=0)
                                           [patio_transb] = Rc_Imp(patio_transb,Navio(acima(contador,1),acima(contador,2))); % retira os cont�ineres que est�o acima e coloc�-os no lugar reservado do p�tio
                                           %[row2]=find(lista_descarregamento==Navio(acima(contador,1),acima(contador,2)));
                                           %lista_descarregamento(row2,:)=[];
                                           Navio(acima(contador,1),acima(contador,2))=0;
                                           MovGeral=MovGeral+1;                                           
                                           acima(contador,:)=0; %transforma o valor em 0, indica que ja foi visto
                                           contador=contador+1;                                        

                                            if sum(sum(acima))==0
                                                break
                                            end
                                        end                            
                                    end
% Termina de retirar quem estava acima
%-------------------------------------------------------------------------------------------------------------------%
% Agora pode retirar o conteiner objetivo  

                         [patio_imp] = Rc_Imp(patio_imp,Navio(i,j)); % se for topo retira e coloca no lugar reservado do p�tio
                         Navio(i,j)=0;
                         MovGeral=MovGeral+1;
                         lista_descarregamento(row,:)=[];                                     
                        end                     
                    end
                end              
            end
        end   
    end
    
% Terminado o descarregamento
%----------------------------------------------------------------------------------------------------------------------%
% Agora � necess�rio carregar os cont�ineres que foram descarregados, mas que n�o tinham como destino final este porto  
    if sum(sum(patio_transb)) ~= 0
        [movgeral,~,Navio] = Rt_descarregamento(patio_transb,navio,RegraRetirada,Navio,RegraCarregamento);
        MovGeral=MovGeral+movgeral;
    end  
    
%     for b=1:length(find(lista_descarregamento(:,1)~=0))
%         [r,c]=find(Navio==lista_descarregamento(b,1));
%         lista_descarregamento(b,3)=r;
%         lista_descarregamento(b,4)=c;        
%     end
            
end


% function [MovGeral, Navio] = Rd1(Navio, NPorto, porto, navio, RegraRetirada,RegraCarregamento)
% 
% MovGeral=0;
% k=length(find(porto==NPorto));
% patio_imp=zeros(ceil(sqrt(k)),ceil(sqrt(k))); % �rea reservada para os cont�ineres de importa��o
% patio_transb=zeros(ceil(sqrt(length(porto)-k)),ceil(sqrt(length(porto)-k))); % �rea reservada para os cont�ineres de transbordo
% [linha,coluna]=size(Navio);
%      for i=1:linha
%         for j=1:coluna
%             if Navio(i,j)~=0 % se a posi��o � diferente de zero
%                 if porto(Navio(i,j))== NPorto % se o cont�iner vai para o porto em que o navio est�
%                     if ((i-1 == 0) || (Navio(i-1,j) == 0)) %Verifica se � topo ou se a posi��o acima � vazia.
%                          [patio_imp] = Rc1(patio_imp,Navio(i,j)); % se for topo retira e coloca no lugar reservado do p�tio
%                          Navio(i,j)=0;
%                          MovGeral=MovGeral+1;                
%                     else % se n�o � topo, remove o cont objetivo e os que est�o em cima
%                          acima = quem_acima(Navio,[i,j]); %vejo quem est� acima dessa posi��o
%                          qtde_troca = 1;
%                          trocas =0;
% 
%                         while(qtde_troca > 0)
%                              qtde_troca = 0; %Condicao de parada
%                              max_acima = size(acima,1);
% 
%                                 if (trocas == max_acima) 
%                                     break
%                                 else
%                                     trocas = trocas +1;
%                                 end
% 
%                                    t = size(acima,1); %quantidade de cont�ineres acima
%                                    contador=1;
% 
%                                     for k = (1:t) % de 1 at� quantidade de posi��es vazias
% 
%                                         if (acima(contador)~=0)
%                                            [patio_transb] = Rc1(patio_transb,Navio(acima(contador,1),acima(contador,2))); % retira os cont�ineres que est�o acima e coloc�-os no lugar reservado do p�tio
%                                            Navio(acima(contador,1),acima(contador,2))=0;
%                                            MovGeral=MovGeral+1;  
%                                            acima(contador,:)=0; %transforma o valor em 0, indica que ja foi visto
%                                            contador=contador+1;                                        
% 
%                                             if sum(sum(acima))==0
%                                                 break
%                                             end
% 
%                                         end                            
%                                     end
% % Termina de retirar quem estava acima
% %-------------------------------------------------------------------------------------------------------------------%
% % Agora pode retirar o conteiner objetivo  
% 
%                              [patio_imp] = Rc1(patio_imp,Navio(i,j)); % se for topo retira e coloca no lugar reservado do p�tio
%                              Navio(i,j)=0;
%                              MovGeral=MovGeral+1;                      
%                         end                     
%                     end 
%                 end
%             end
%         end   
%     end
%     
% % Terminado o descarregamento
% %----------------------------------------------------------------------------------------------------------------------%
% % Agora � necess�rio carregar os cont�ineres que foram descarregados, mas que n�o tinham como destino final este porto  
%     if sum(sum(patio_transb)) ~= 0
%         [movgeral,~,~,Navio] = Rt_descarregamento(patio_transb,navio,RegraRetirada,Navio,RegraCarregamento);
%         MovGeral=MovGeral+movgeral;
%     end     
%             
% end

