%----------------------------------------------------%
%----------------------------------------------------%
% Elabora��o da Regra R1 de Carregamento.            %
%----------------------------------------------------%
%----------------------------------------------------%
% Procedimento de preenchimento:                     %
%----------------------------------------------------%
%  (1) Considera-se que a ordem de preenchimento
%      das cargas no navios ->, ou seja, da 
%      esquerda para a direita de baixo para cima.  
%      m ^
%        |
%        |
%      1 -----> 
%        1    n
%
%  (2) Recebe uma matriz M vazia ou parcialmente 
%      preenchida, bem como um vetor D com cargas
%      do i-esimo porto.
%
%  (3) Retorna a matriz M com as cargas contidas no 
%      vetor D preenchidas de acordo com a regra RE1.
%----------------------------------------------------%
function [M, MovGeral] = fre1(M,D) 









end

